create table users (
	users_id INT,
	users_username VARCHAR(50),
	users_password VARCHAR(200)
);
insert into users (users_id, users_username, users_password) values (1, 'ebassford0', '$2y$10$SALH4SoHEgra8BGaTT7HDeNyTs4RI8VPkzNT2uysp8EsBwAgiDrz6');
insert into users (users_id, users_username, users_password) values (2, 'ltitheridge1', '$2y$10$CMpxy.fFnJ3zMcqdyB6/VuaSGvE3RLkFmABGvYycKuG.Lov0tABsK');
insert into users (users_id, users_username, users_password) values (3, 'lbelch2', '$2y$10$yhVNTu.6USmJR7WxGFN7KOvjAZmVBR0gwiQOKZfQcm/c5KZxRah2S');
insert into users (users_id, users_username, users_password) values (4, 'cryves3', '$2y$10$GAn3cTLLlg67tnalUIUDOuT2QZnzbPzC5j5udayftiTBn5YvkiD6a');
insert into users (users_id, users_username, users_password) values (5, 'mjindracek4', '$2y$10$ciY4gKgivkUzxcWJlYetF.q5quUArpS3wxnigx8HfIYo.IvYOlSZm');
insert into users (users_id, users_username, users_password) values (6, 'rsnowdon5', '$2y$10$0ltJXOnElkRGnbTjVneHxusUGL2X12Gt3Sj6BvgrmlWksZNasH6eq');
insert into users (users_id, users_username, users_password) values (7, 'sledgeway6', '$2y$10$JkVHYelxA9VmhNIf7w292.QoAG7LWXXgyg3Lu/XG0XZTmQGQ5tXDK');
insert into users (users_id, users_username, users_password) values (8, 'lgoodfield7', '$2y$10$fTlMCoasyUpWjU2qF5DMn.UsGy5ZTlmJeVv.tnnp.KKIqv5yNnfsG');
insert into users (users_id, users_username, users_password) values (9, 'fgludor8', '$2y$10$//0b62jB4ZSDyxyXnHo/hOn7xlszTyahOR6oZqFZZ435fo0GolN4q');
insert into users (users_id, users_username, users_password) values (10, 'bkenewel9', '$2y$10$ttEEjHku.XdLY2IciwSWx.XROAImjMBFHaifly9xkihbkV/8SKvNO');
insert into users (users_id, users_username, users_password) values (11, 'root', '$2y$10$e30yONVlDd30BbQdttYcq.3y2Xkn1caVUDXjiwx/Uyqz7ZSxYXJ.q');
insert into users (users_id, users_username, users_password) values (12, 'test', '$2y$10$GtiJHhJL3ea52aj9ev1sT.KUQuOzkG8hHpjClLVBt.FklbfbeYy4W'); -- 'password'
